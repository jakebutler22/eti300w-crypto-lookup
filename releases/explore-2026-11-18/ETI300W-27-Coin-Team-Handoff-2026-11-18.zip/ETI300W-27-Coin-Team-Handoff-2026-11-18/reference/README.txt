These are supporting references, not the single final Canvas submission.

Alex supplied the editable SVG diagram and PNG/PDF exports on Nov. 18.
Confirm resource associations and update the diagram only when actual topology changes.
NOLAN_MIDDLEWARE_DRAFT.md is edited wording based on the prior deployment narrative.
Pair it with actual service/query/API screenshots and update it after an approved upgrade.
backend-candidate-provenance.json identifies every unchanged supplied candidate file.
No screenshot has been fabricated or substituted for actual cloud evidence.
