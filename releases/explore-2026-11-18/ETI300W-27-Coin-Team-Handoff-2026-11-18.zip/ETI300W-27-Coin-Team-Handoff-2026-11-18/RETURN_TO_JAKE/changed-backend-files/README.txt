Return only changes/corrections since the supplied upgrade, with a brief diff summary.
Do not resend unchanged files or include .env, credentials, SSH keys, access keys or private addresses.
Describe migrations as proposed or applied after specific approval, with real test evidence.
