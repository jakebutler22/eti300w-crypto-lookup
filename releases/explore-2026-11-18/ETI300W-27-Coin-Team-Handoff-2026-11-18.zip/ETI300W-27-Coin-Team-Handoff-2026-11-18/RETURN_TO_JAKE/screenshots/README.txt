Add actual readable cloud screenshots, not screenshots of written reports or text captures.
For each, provide filename, capture time, source instance/role and a caption stating what it proves.
Nolan: running middleware, successful request, coordinated actual app-to-DB query.
Alex: three instances, service status, database schema/27 rows, private VPC path/rules/routes.
Jake: finished hosted interface and acceptance checks after approved deployment.
Redact credentials, keys, private addresses and unrelated personal details before returning.
