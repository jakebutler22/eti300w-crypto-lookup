Add actual sanitized response JSON plus public path, HTTP status and capture time.
Identify current deployment/version and whether it is before or after any approved upgrade.
Requested examples: current27 catalog, BTC/ETH market success, safe failures, agreed combined success/failure.
Do not label candidate README examples or mocked test fixtures as real deployed results.
